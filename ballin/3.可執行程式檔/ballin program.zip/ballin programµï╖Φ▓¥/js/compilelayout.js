var headertxt;
var footertxt;

function comData(data) {
    const defaultData = {
        part: "",
        bgColor: "transparent",
        color: "#fff",
        title: "",
        icon: []
    };
    let mergeData = defaultData;
    if (data != null) {
        for (const [key, value] of Object.entries(data)) {
            if (value != "") {
                mergeData[key] = data[key];
            }
        }
    }

    let opt = {
        part: mergeData.part,
        bgColor: mergeData.bgColor,
        color: mergeData.color,
        title: mergeData.title,
        icon: mergeData.icon
    }

    getDom(opt);
    let layout = {
        header: headertxt,
        footer: footertxt
    };
    achieveData(opt, layout);
}

function achieveData(opt, layout) {
    if (opt.part != "") {
        compilerData(`#section_${opt.part}`, `#${opt.part}`, layout);
    } else {
        compilerData("#section_header", "#header", layout);
        compilerData("#section_footer", "#footer", layout);
    }
}

function compilerData(idDom, idContent, data) {
    var content = $(idDom).html(); //取得上列的template內容
    var template = Handlebars.compile(content);
    var html = template(data);
    $(idContent).append(html); //直接把html片段加到body中
}


function getDom(opt) {
    var url = 'layout.html';
    var headerDom = "";
    var footerDom = "";
    $.ajax({
        url: url,
        type: "GET",
        async: false,
        success: function (response) {
            if (opt.part != "footer") {
                let strheaderDom = $(response).filter("header");
                let iconObj = strheaderDom.find('[data-icon]');
                var allIconId = iconObj.map(function () {
                    return $(this).data('icon');
                }).get();

                var difference = [];
                jQuery.grep(allIconId, function (el) {
                    if (jQuery.inArray(el, opt.icon) == -1) difference.push(el);
                });

                for (let i = 0; i < difference.length; i++) {
                    strheaderDom.find(`[data-icon="${difference[i]}"]`).remove();
                }

                let bgObj = strheaderDom.find('[data-bgcolor]');
                bgObj.css("background", opt.bgColor);
                bgObj.css("color", opt.color);
                bgObj.children('[data-title]').text(opt.title);

                headerDom = strheaderDom[0].outerHTML;
            } else {
                headerDom = $(response).filter("header")[0].outerHTML;
            }

            footerDom = $(response).filter("footer")[0].outerHTML;
            headertxt = rmbreak(headerDom);
            footertxt = rmbreak(footerDom);
        }, error: function (err) {
            console.log('err')
        }
    })
}
function rmbreak(data) {
    var someText = data;
    //This javascript code removes all 3 types of line breaks
    someText = someText.replace(/(\r\n|\n|\r)/gm, "");
    someText = someText.replace(/\s+/g, " ");
    someText = someText.replace(/'/g, '"');
    return String(someText);
};

