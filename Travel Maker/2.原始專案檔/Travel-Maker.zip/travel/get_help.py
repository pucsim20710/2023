def get_help():
    info =  "傳送縣市名稱--會顯示縣市所有景點" + "\n"
    info += "介紹+景點名稱--可以查詢到想要的景點資訊" + "\n"
    info += "縣市+天氣 ----可以查詢天氣資訊" + "\n"
    info += "其他訊息依然可以回覆"
    return info

# print(get_help())